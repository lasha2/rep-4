class Latte constructor(var sugar:Int, var milk:Int) {

    private val latte_price=4
    private val sugar_price=2
    private val milk_price=3

    private var total_price=0

    fun get_price():Int
    {

            total_price = latte_price + sugar*sugar_price + milk*milk_price

        return total_price

    }


}