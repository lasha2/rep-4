class Cappuccino constructor(var sugar:Int, var milk:Int, var hasCinnamon:Boolean) {

    private val cappucino_price=2
    private val cinammon_price=1
    private val sugar_price=2
    private val milk_price=3
    private var total_price=0
    fun get_price():Int
    {
        if (hasCinnamon == true) {
             total_price = cappucino_price + sugar*sugar_price + milk*milk_price + cinammon_price
        } else {
             total_price = cappucino_price + sugar + milk
        }
        return total_price

    }


}