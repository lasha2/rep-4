import java.lang.System.`in`
import java.util.*

fun main()
{
    val scanner =  Scanner(`in`)
    val coffeeMachine=CoffeeMachine(scanner)
    coffeeMachine.request()

}


class CoffeeMachine constructor(private val scanner:Scanner)
{

    fun request()
    {
        println ("romeli yava ginda? [latte/cappuccino]")
        val coffee_type=scanner.next()


        if(coffee_type=="latte")
        {
            requestlatte()
        }else
        {
            requestCappucino()
        }


    }
    private var sugar=0
    private  var milk=0
    private var cinnamon=false

    private fun requestlatte() {
println ("ramdeni shaqari ginda[miutite cifri]?")
        sugar=scanner.nextInt()
        println ("ramdeni rdze ginda[miutite cifri]?")
        milk=scanner.nextInt()

        var latte=Latte(sugar,milk)
        println ("late cost is: " + latte.get_price() )

    }


    private fun requestCappucino() {
        println ("ramdeni shaqari ginda[miutite cifri]?")
        sugar=scanner.nextInt()
        println ("ramdeni rdze ginda[miutite cifri]?")
        milk=scanner.nextInt()
        println ("darichini ginda? [ true/false]")
        cinnamon= scanner.nextBoolean()
        var cappuccino=Cappuccino(sugar,milk,cinnamon)

        println ("cappuccino cost is" + cappuccino.get_price() )


    }

}